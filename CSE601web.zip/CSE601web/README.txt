This is a J2EE servlet with HTML Application. Application is develeloped on JDK1.7 and above and Tomcat7. 
To run the application please deploay the war file present in the folder.